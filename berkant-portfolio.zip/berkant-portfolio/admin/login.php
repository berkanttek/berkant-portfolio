<?php
session_start();

if (isset($_SESSION['admin'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../db.php';
    
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['admin'] = $user['username'];
        $_SESSION['login_time'] = time();
        setcookie('last_login', date('Y-m-d H:i:s'), time() + 30 * 24 * 3600, '/');
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Kullanıcı adı veya şifre hatalı.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Girişi — Berkant Tekkanat</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&family=Space+Mono&display=swap" rel="stylesheet"/>
</head>
<body>
  <div class="cursor"></div>
  <div class="cursor-follower"></div>

  <div class="admin-wrap">
    <div class="admin-box">
      <h1>ADMİN <span style="color:var(--accent)">GİRİŞİ</span></h1>
      <p>Portföy yönetim paneline hoş geldin.</p>

      <?php if ($error): ?>
        <div class="admin-alert error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form class="admin-form" method="POST">
        <div class="form-group">
          <label>KULLANICI ADI</label>
          <input type="text" name="username" required autocomplete="username"/>
        </div>
        <div class="form-group">
          <label>ŞİFRE</label>
          <input type="password" name="password" required autocomplete="current-password"/>
        </div>
        <button type="submit" class="btn-submit">GİRİŞ YAP</button>
      </form>

      <?php if (isset($_COOKIE['last_login'])): ?>
        <p style="margin-top:1.5rem; font-size:0.75rem; color:var(--muted); font-family:'Space Mono',monospace;">
          Son giriş: <?= htmlspecialchars($_COOKIE['last_login']) ?>
        </p>
      <?php endif; ?>
    </div>
  </div>

  <script src="../js/main.js"></script>
</body>
</html>