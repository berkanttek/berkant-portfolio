<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// Proje ekle / güncelle / sil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $title       = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $tech        = trim($_POST['tech_stack'] ?? '');
        $github      = trim($_POST['github_url'] ?? '');
        $live        = trim($_POST['live_url'] ?? '');

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO projects (title, description, tech_stack, github_url, live_url) VALUES (?,?,?,?,?)");
            $stmt->execute([$title, $description, $tech, $github, $live]);
        } else {
            $id = (int)$_POST['id'];
            $stmt = $pdo->prepare("UPDATE projects SET title=?, description=?, tech_stack=?, github_url=?, live_url=? WHERE id=?");
            $stmt->execute([$title, $description, $tech, $github, $live, $id]);
        }
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM projects WHERE id=?")->execute([$id]);
    }

    header('Location: dashboard.php');
    exit;
}

$projects = $pdo->query("SELECT * FROM projects ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$messages = $pdo->query("SELECT * FROM messages ORDER BY sent_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard — Berkant Tekkanat</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&family=Space+Mono&display=swap" rel="stylesheet"/>
</head>
<body>
  <div class="cursor"></div>
  <div class="cursor-follower"></div>

  <div class="dashboard-wrap">
    <div class="dash-header">
      <h1>PROJE <span style="color:var(--accent)">DASHBOARD</span></h1>
      <div style="display:flex;gap:1rem;">
        <button class="btn-add" onclick="openModal()">+ YENİ PROJE</button>
        <a href="../php/logout.php"><button class="btn-logout">ÇIKIŞ YAP</button></a>
      </div>
    </div>

    <p style="color:var(--muted);font-family:'Space Mono',monospace;font-size:0.75rem;margin-bottom:2rem;">
      Hoş geldin, <strong style="color:var(--accent)"><?= htmlspecialchars($_SESSION['admin']) ?></strong>
      — Oturum: <?= date('H:i', $_SESSION['login_time']) ?>
    </p>

    <!-- Projeler Tablosu -->
    <table class="projects-table">
      <thead>
        <tr>
          <th>#</th>
          <th>BAŞLIK</th>
          <th>TEKNOLOJİLER</th>
          <th>TARİH</th>
          <th>İŞLEMLER</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($projects as $i => $p): ?>
        <tr>
          <td style="color:var(--muted);font-family:'Space Mono',monospace;">0<?= $i+1 ?></td>
          <td><?= htmlspecialchars($p['title']) ?></td>
          <td style="color:var(--muted);font-size:0.8rem;"><?= htmlspecialchars($p['tech_stack']) ?></td>
          <td style="color:var(--muted);font-size:0.8rem;font-family:'Space Mono',monospace;">
            <?= date('d.m.Y', strtotime($p['created_at'])) ?>
          </td>
          <td style="display:flex;gap:0.5rem;">
            <button class="btn-edit" onclick="openEdit(<?= htmlspecialchars(json_encode($p)) ?>)">DÜZENLE</button>
            <form method="POST" style="display:inline" onsubmit="return confirm('Silmek istediğine emin misin?')">
              <input type="hidden" name="action" value="delete"/>
              <input type="hidden" name="id" value="<?= $p['id'] ?>"/>
              <button type="submit" class="btn-delete">SİL</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Mesajlar -->
    <div class="messages-section">
      <h2>GELEN <span style="color:var(--accent)">MESAJLAR</span></h2>
      <table class="projects-table">
        <thead>
          <tr>
            <th>İSİM</th>
            <th>E-POSTA</th>
            <th>MESAJ</th>
            <th>TARİH</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($messages)): ?>
          <tr><td colspan="4" style="color:var(--muted);font-family:'Space Mono',monospace;font-size:0.8rem;">Henüz mesaj yok.</td></tr>
          <?php endif; ?>
          <?php foreach ($messages as $m): ?>
          <tr>
            <td><?= htmlspecialchars($m['name']) ?></td>
            <td style="color:var(--muted);font-size:0.85rem;"><?= htmlspecialchars($m['email']) ?></td>
            <td style="color:var(--muted);font-size:0.85rem;max-width:300px;"><?= htmlspecialchars($m['message']) ?></td>
            <td style="color:var(--muted);font-size:0.8rem;font-family:'Space Mono',monospace;">
              <?= date('d.m.Y H:i', strtotime($m['sent_at'])) ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal-overlay hidden" id="modalOverlay">
    <div class="modal-box">
      <h2 id="modalTitle">YENİ <span style="color:var(--accent)">PROJE</span></h2>
      <form class="modal-form" method="POST">
        <input type="hidden" name="action" id="formAction" value="add"/>
        <input type="hidden" name="id" id="formId" value=""/>
        <div class="form-group">
          <label>BAŞLIK</label>
          <input type="text" name="title" id="formTitle" required/>
        </div>
        <div class="form-group">
          <label>AÇIKLAMA</label>
          <textarea name="description" id="formDesc" required></textarea>
        </div>
        <div class="form-group">
          <label>TEKNOLOJİLER (virgülle ayır)</label>
          <input type="text" name="tech_stack" id="formTech" placeholder="HTML, CSS, JS"/>
        </div>
        <div class="form-group">
          <label>GITHUB URL</label>
          <input type="text" name="github_url" id="formGithub" placeholder="https://github.com/..."/>
        </div>
        <div class="form-group">
          <label>LIVE DEMO URL</label>
          <input type="text" name="live_url" id="formLive" placeholder="https://..."/>
        </div>
        <div class="modal-btns">
          <button type="submit" class="btn-submit">KAYDET</button>
          <button type="button" class="btn-cancel" onclick="closeModal()">İPTAL</button>
        </div>
      </form>
    </div>
  </div>

  <script src="../js/main.js"></script>
  <script>
    function openModal() {
      document.getElementById('modalTitle').innerHTML = 'YENİ <span style="color:var(--accent)">PROJE</span>';
      document.getElementById('formAction').value = 'add';
      document.getElementById('formId').value = '';
      document.getElementById('formTitle').value = '';
      document.getElementById('formDesc').value = '';
      document.getElementById('formTech').value = '';
      document.getElementById('formGithub').value = '';
      document.getElementById('formLive').value = '';
      document.getElementById('modalOverlay').classList.remove('hidden');
    }

    function openEdit(p) {
      document.getElementById('modalTitle').innerHTML = 'PROJEYİ <span style="color:var(--accent)">DÜZENLE</span>';
      document.getElementById('formAction').value = 'edit';
      document.getElementById('formId').value = p.id;
      document.getElementById('formTitle').value = p.title;
      document.getElementById('formDesc').value = p.description;
      document.getElementById('formTech').value = p.tech_stack;
      document.getElementById('formGithub').value = p.github_url;
      document.getElementById('formLive').value = p.live_url;
      document.getElementById('modalOverlay').classList.remove('hidden');
    }

    function closeModal() {
      document.getElementById('modalOverlay').classList.add('hidden');
    }

    document.getElementById('modalOverlay').addEventListener('click', (e) => {
      if (e.target === document.getElementById('modalOverlay')) closeModal();
    });
  </script>
</body>
</html>