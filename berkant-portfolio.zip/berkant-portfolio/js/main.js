// ============================================
// BERKANT TEKKANAT — main.js
// ============================================

// ─── LOADING SCREEN ───
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (loader) loader.classList.add('hide');
  }, 2000);
});

// ─── DARK / LIGHT MODE TOGGLE ───
const toggleBtn = document.getElementById('modeToggle');
if (toggleBtn) {
  const savedMode = getCookie('theme');
  if (savedMode === 'light') {
    document.body.classList.add('light-mode');
  }

  toggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    const isLight = document.body.classList.contains('light-mode');
    setCookie('theme', isLight ? 'light' : 'dark', 30);
  });
}

// ─── COOKIE HELPERS ───
function setCookie(name, value, days) {
  const d = new Date();
  d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `${name}=${value};expires=${d.toUTCString()};path=/`;
}

function getCookie(name) {
  const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
  return match ? match[2] : null;
}

// ─── FORM VALIDATION ───
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();

    const name    = document.getElementById('name');
    const email   = document.getElementById('email');
    const message = document.getElementById('message');
    let valid = true;

    if (name.value.trim().length < 2) {
      showError(name, 'name-error', 'İsim en az 2 karakter olmalı.');
      valid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.value.trim())) {
      showError(email, 'email-error', 'Geçerli bir e-posta adresi girin.');
      valid = false;
    }

    if (message.value.trim().length < 10) {
      showError(message, 'message-error', 'Mesaj en az 10 karakter olmalı.');
      valid = false;
    }

    if (!valid) return;

    const btn = contactForm.querySelector('.btn-submit');
    btn.textContent = 'GÖNDERİLİYOR...';
    btn.disabled = true;

    const formData = new FormData(contactForm);

    try {
      const res  = await fetch('php/contact.php', { method: 'POST', body: formData });
      const data = await res.json();
      const status = document.getElementById('formStatus');

      if (data.success) {
        status.textContent = '✓ Mesajın alındı, en kısa sürede dönüş yapacağım!';
        status.className = 'form-status success';
        contactForm.reset();
      } else {
        status.textContent = '✗ Bir hata oluştu, tekrar dene.';
        status.className = 'form-status error';
      }
    } catch {
      const status = document.getElementById('formStatus');
      status.textContent = '✗ Sunucu bağlantı hatası.';
      status.className = 'form-status error';
    }

    btn.textContent = 'GÖNDER';
    btn.disabled = false;
  });
}

function showError(input, errorId, msg) {
  input.classList.add('error');
  const el = document.getElementById(errorId);
  if (el) { el.textContent = msg; el.classList.add('show'); }
}

function clearErrors() {
  document.querySelectorAll('.form-group input, .form-group textarea').forEach(el => {
    el.classList.remove('error');
  });
  document.querySelectorAll('.form-error').forEach(el => {
    el.classList.remove('show');
  });
  const status = document.getElementById('formStatus');
  if (status) status.className = 'form-status';
}

// ─── AJAX: PROJELERİ VERİTABANINDAN ÇEK ───
async function loadProjects() {
  const grid = document.getElementById('projectsGrid');
  if (!grid) return;

  grid.innerHTML = '<p class="projects-loading">PROJELER YÜKLENİYOR...</p>';

  try {
    const res  = await fetch('php/get_projects.php');
    const data = await res.json();

    if (!data.length) {
      grid.innerHTML = '<p class="projects-loading">Henüz proje eklenmedi.</p>';
      return;
    }

    grid.innerHTML = data.map((p, i) => `
      <div class="project-card">
        <div class="card-num">0${i + 1}</div>
        <h3 class="card-title">${p.title}</h3>
        <p class="card-desc">${p.description}</p>
        <div class="card-tech">
          ${p.tech_stack.split(',').map(t => `<span>${t.trim()}</span>`).join('')}
        </div>
        <div class="card-links">
          ${p.github_url && p.github_url !== '#' ? `<a href="${p.github_url}" target="_blank">↗ GitHub</a>` : ''}
          ${p.live_url && p.live_url !== '#' ? `<a href="${p.live_url}" target="_blank">↗ Live Demo</a>` : ''}
        </div>
      </div>
    `).join('');

  } catch {
    grid.innerHTML = '<p class="projects-loading">Projeler yüklenemedi.</p>';
  }
}

document.addEventListener('DOMContentLoaded', loadProjects);

// ─── SCROLL ANİMASYONLARI ───
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.project-card, .stat-item, .skill-tag').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
});

// ─── KUYRUKLU YILDIZ FARE EFEKTİ ───
(function() {
  const starCanvas = document.createElement('canvas');
  starCanvas.style.cssText = 'position:fixed;inset:0;z-index:9997;pointer-events:none;';
  document.body.appendChild(starCanvas);
  const sCtx = starCanvas.getContext('2d');

  function resize() {
    starCanvas.width  = window.innerWidth;
    starCanvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const stars = [];

  function isLight() {
    return document.body.classList.contains('light-mode');
  }

  window.addEventListener('mousemove', e => {
    for (let i = 0; i < 4; i++) {
      stars.push({
        x:     e.clientX + (Math.random() - 0.5) * 6,
        y:     e.clientY + (Math.random() - 0.5) * 6,
        size:  Math.random() * 2.5 + 0.5,
        alpha: 1,
        vx:    (Math.random() - 0.5) * 1.2,
        vy:    (Math.random() - 0.5) * 1.2 - 0.3,
      });
    }
  });

  function drawStars() {
    sCtx.clearRect(0, 0, starCanvas.width, starCanvas.height);

    // Siyah temada beyaz, beyaz temada koyu gri
    const c = isLight() ? '80, 80, 80' : '255, 255, 255';

    for (let i = stars.length - 1; i >= 0; i--) {
      const s = stars[i];
      s.alpha -= 0.035;
      s.size  *= 0.96;
      s.x += s.vx;
      s.y += s.vy;

      if (s.alpha <= 0) { stars.splice(i, 1); continue; }

      const g = sCtx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.size * 6);
      g.addColorStop(0,   `rgba(${c}, ${s.alpha * 0.4})`);
      g.addColorStop(0.3, `rgba(${c}, ${s.alpha * 0.15})`);
      g.addColorStop(1,   `rgba(${c}, 0)`);

      sCtx.beginPath();
      sCtx.arc(s.x, s.y, s.size * 6, 0, Math.PI * 2);
      sCtx.fillStyle = g;
      sCtx.fill();

      sCtx.beginPath();
      sCtx.arc(s.x, s.y, s.size * 0.7, 0, Math.PI * 2);
      sCtx.fillStyle = `rgba(${c}, ${s.alpha})`;
      sCtx.fill();

      sCtx.save();
      sCtx.globalAlpha = s.alpha * 0.5;
      sCtx.strokeStyle = `rgba(${c}, 0.4)`;
      sCtx.lineWidth = 0.6;
      sCtx.translate(s.x, s.y);
      for (let angle = 0; angle < Math.PI; angle += Math.PI / 2) {
        sCtx.beginPath();
        sCtx.moveTo(Math.cos(angle) * s.size * 5, Math.sin(angle) * s.size * 5);
        sCtx.lineTo(-Math.cos(angle) * s.size * 5, -Math.sin(angle) * s.size * 5);
        sCtx.stroke();
      }
      sCtx.restore();
    }

    requestAnimationFrame(drawStars);
  }

  drawStars();
})();